POCKETBASE_BASE_URL = "http://localhost:8090/api/collections/"
RESEND_API_KEY = "re_X1V7kQu9_NxCpftR6ve6kxXEUT7Yrqw7c"
